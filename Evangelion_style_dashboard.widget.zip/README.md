# Evangelion-Uebersicht-Widget
## Installation
Who am I kidding, the only thing you need to know is this is a widget for Übersicht, http://tracesof.net/uebersicht/

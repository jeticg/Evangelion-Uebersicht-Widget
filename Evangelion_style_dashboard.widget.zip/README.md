# Evangelion-Übersicht-Widget
## Updates

0.52a
* Added function: empty trash on clicking the trash cell

0.51a
* Fixed a bug, where it used to show countdown when not supposed to

0.5a
* Added left-bottom corner panel
* Added iTunes remote cell

0.45a
* Fixed problem with the hovering effect of IPCell
* Change from Simplified Chinese to Traditional (This is actually a mistake I made in the early phase of coding)

0.44a
* Fixed IP displaying when there’s no internet connection

0.43a
* Bug fix for OSX 10.10 (mine is 10.11)

0.42a
* Improved alarm, bug fixed
* Added animation to alarm

0.41a
* Added blinking when alert triggered

0.4a
* Added alert system, will alert when battery is below 20% or when CPU usage reaches 90%
* restructured the code, added comments

0.3a
* Added Memory and CPU usage
* Colour scheme changed
* Error message changed

0.22a
* Improved Trash Issue
* Output cells enabled, press on cell 32 and information will popup

0.22a
* Improved Trash Issue
* Output cells enabled, press on cell 32 and information will popup

0.21a
* Fixed Trash

0.2a
* Fix battery hover

0.1a
* Added General UI
* Added Battery
* Added Time and Day

## Installation
Who am I kidding, the only thing you need to know is this is a widget for Übersicht, http://tracesof.net/uebersicht/
